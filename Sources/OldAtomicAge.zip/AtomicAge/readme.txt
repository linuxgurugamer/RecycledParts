This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

This package redistributes the following mods and plugins, their license information can be found in the provided links:

ModuleManager - made by Sarbian & Ialdabaoth - http://forum.kerbalspaceprogram.com/threads/55219-Module-Manager-1-5-6-%28Jan-6%29

Community Tech Tree by Nertea - http://forum.kerbalspaceprogram.com/threads/100385-Community-Tech-Tree-1-1-last-updated-19-11-14

Patches from Deimos Rast have been merged in for compatibility with 1.3

the lines "mesh =" have been replaced with MODEL nodes
The radiators which already had the MODEL nodes had the paths updated
